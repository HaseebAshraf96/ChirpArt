package com.example.haseebashraf.chirpwithart;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import org.json.JSONException;

import io.chirp.sdk.CallbackRead;
import io.chirp.sdk.ChirpSDK;
import io.chirp.sdk.ChirpSDKListener;
import io.chirp.sdk.model.Chirp;
import io.chirp.sdk.model.ChirpError;
import io.chirp.sdk.model.ShortCode;
import java.util.*;
import java.util.regex.*;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);
        //Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        //setSupportActionBar(toolbar);

        //FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        //fab.setOnClickListener(new View.OnClickListener() {
        //    @Override
        //    public void onClick(View view) {
        //        Snackbar.make(view, "ITL BOIZZ 5 LYFE", Snackbar.LENGTH_LONG)
        //                .setAction("Action", null).show();
        //    }
        //});
        final MyView v = new MyView(this);
        setContentView(v);

        final ChirpSDK chirpSDK = new ChirpSDK(this, "WBjCb0AOmkI8KuKH2dXJ3dZTt", "bkXd7Gko3mgXF2pseWiVGPdkLjjbTsMGc9gwdRfRrgOQRmMnyl");

        chirpSDK.setListener(new ChirpSDKListener() {

            @Override
            public void onChirpHeard(ShortCode shortCode) {
                Log.v("leapbird", "chirper " + shortCode.getShortCode());
                chirpSDK.read(shortCode, new CallbackRead() {

                    @Override
                    public void onReadResponse(Chirp chirp) {
                        Log.d("leapbird", "chirper " + chirp.getJsonData().toString());

                        final ArrayList<int[]> points = new ArrayList<int[]>();

                        // Pattern to match any digit and any trailing zeroes
                        Pattern p = Pattern.compile("x:([0-9]+)y:([0-9]+)");

                        Matcher m = null;
                        try {
                            System.out.println(chirp.getJsonData().get("Payload").toString());
                            m = p.matcher(chirp.getJsonData().get("Payload").toString());
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        while (m.find()) {
                            points.add(new int[]{Integer.parseInt(m.group(1)), Integer.parseInt(m.group(2))});
                        }
                        System.out.println(points.size());
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                v.setPoints(points);
                                v.invalidate();
                            }
                        });


                    }


                    @Override
                    public void onReadError(ChirpError chirpError) {
                        Log.d("leapbird", "chirper read error " + chirpError.getMessage());
                    }
                });

            }

            @Override
            public void onChirpError(ChirpError chirpError) {
                Log.d("leapbird", "chirper error" + chirpError.getMessage());
            }
        });
        chirpSDK.startListening();

    }

    public class MyView extends View
    {
        private ArrayList<int[]> points = new ArrayList<>();
        public MyView(Context context)
        {
            super(context);
        }

        public void setPoints(ArrayList<int[]> p) {
            points = p;
        }

        @Override
        protected void onDraw(Canvas canvas)
        {
            super.onDraw(canvas);
            int x = 1280;
            System.out.println(getWidth());
            int y = 720;
            System.out.println(getHeight());
            int radius;
            radius = 5;
            Paint paint = new Paint();
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.BLACK);
            canvas.drawPaint(paint);
            // Use Color.parseColor to define HTML colors
            paint.setColor(Color.parseColor("#ffffff"));

            System.out.println(points.size());
            for (int j = 0; j < points.size() - 1; j++) {
                canvas.drawLine(points.get(j)[0], points.get(j)[1], points.get(j + 1)[0], points.get(j + 1)[1], paint);

            }

        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
